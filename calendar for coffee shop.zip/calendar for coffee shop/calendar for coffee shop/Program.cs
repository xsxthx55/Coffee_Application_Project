﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calendar_for_coffee_shop
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("Welcome to the Dog Meeting Scheduler!");

            // Get user input for the day
            Console.Write("Enter the day for the meeting: ");
            string day = Console.ReadLine();

            // Get user input for the time
            Console.Write("Enter the time for the meeting: ");
            string time = Console.ReadLine();

            // Display the scheduled meeting information
            Console.WriteLine("\nScheduled Dog Meeting:");
            Console.WriteLine($"Day: {day}");
            Console.WriteLine($"Time: {time}");

            // Additional logic or actions can be added here

            Console.WriteLine("\nThank you for scheduling a meeting with the dog!");
            Console.ReadLine();
        }
        







    }
    }

