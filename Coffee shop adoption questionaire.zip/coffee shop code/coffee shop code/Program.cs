﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coffee_shop_code
{
    internal class Program
    {
        static void Main(string[] args)
        {
        

        {
           
            {
                Console.WriteLine("Welcome to the Dog Adoption Page");

                // Ask the customer for their information
                Console.Write("What is your age: ");
                int age;
                if (int.TryParse(Console.ReadLine(), out age))
                {
                    Console.Write("Do you have a stable source of income? (yes/no): ");
                    string incomeStatus = Console.ReadLine().ToLower();

                    Console.Write("How many hours per day can you spend with a dog (on average): ");
                    double dailyHours;
                    if (double.TryParse(Console.ReadLine(), out dailyHours))
                    {
                        Console.Write("Have you owned a dog before? (yes/no): ");
                        string previousDogOwner = Console.ReadLine().ToLower();

                        Console.Write("Do you have a secure and spacious yard for the dog to play in? (yes/no): ");
                        string hasYard = Console.ReadLine().ToLower();

                        // Check eligibility based on the criteria
                        if (age >= 18 && incomeStatus == "yes" && dailyHours >= 2.0 && previousDogOwner == "yes" && hasYard == "yes")
                        {
                            Console.WriteLine("Congratulations! You are eligible to adopt a dog. See the calendar for an available time to meet our pups!");
                        }
                        else
                        {
                            Console.WriteLine("Sorry, you are not eligible to adopt a dog based on the provided information.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input for daily hours. Please enter a valid number.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input for age. Please enter a valid number.");
                }
            }
        }

        Console.ReadLine();
            }
        }

















    }


